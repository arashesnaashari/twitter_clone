const App = () => {
  return (
    <>
      <div className="bg-zinc-800 rounded-xl w-3/4 p-4 mb-4 flex justify-center">
        <input
          className=" border-0 rounded-md p-3 bg-zinc-700"
          placeholder="Search .."
        />
      </div>
    </>
  );
};

export default App;
