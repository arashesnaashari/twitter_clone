import { useState, useEffect, useContext } from "react";

const App = ({ username }) => {
  return <h1>SSs</h1>;
};

export default App;
