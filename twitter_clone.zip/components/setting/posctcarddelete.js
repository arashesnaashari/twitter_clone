import TimeAgo from "timeago-react";

import Link from "next/link";
import userInfo from "../../context/userInfo";

const App = ({ color, like, bookmark, date, id }) => {
  return <></>;
};

export default App;
