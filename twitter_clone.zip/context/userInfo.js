import React from "react";

export default React.createContext({
  // token: null,
  userId: null,
  profile: null,
  username: null,
  // login: (token, userId, username, profileURL) => {},
  // logout: () => {},
  //   modal: false,
  //   setModel: () => {},
  //   clozeModal: () => {},
});
